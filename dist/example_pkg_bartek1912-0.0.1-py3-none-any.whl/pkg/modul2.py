def addOne(x):
    return x+1